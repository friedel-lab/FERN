/*
 * Created on 12.03.2007
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fern.network;

public class FeatureNotSupportedException extends Exception {
private static final long serialVersionUID = 1L;

	public FeatureNotSupportedException(String msg) {
		super(msg);
	}
}
